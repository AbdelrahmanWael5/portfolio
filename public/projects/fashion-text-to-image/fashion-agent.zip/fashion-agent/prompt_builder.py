from state import FashionState

from prompts import (
    CONSULTANT_PROMPT,
    EXTRACTOR_PROMPT,
)

from validators import get_missing_attributes


####################################################
# Consultant Prompt
####################################################

def build_consultant_prompt(state: FashionState):

    known_details = []

    fields = [
        ("Category", state["category"]),
        ("Color", state["color"]),
        ("Material", state["material"]),
        ("Fit", state["fit"]),
        ("Neckline", state["neckline"]),
        ("Sleeve Length", state["sleeve_length"]),
        ("Pattern", state["pattern"]),
    ]

    for name, value in fields:

        if value is not None:

            known_details.append(
                f"- {name}: {value}"
            )

    if not known_details:

        known_text = "None"

    else:

        known_text = "\n".join(known_details)

    missing = get_missing_attributes(state)

    if not missing:

        missing_text = "None"

    else:

        missing_text = "\n".join(
            f"- {item.replace('_', ' ').title()}"
            for item in missing
        )

    if len(state["messages"]) == 0:

        history = "No previous conversation."

    else:

        history = "\n".join(
            f"{m['role'].capitalize()}: {m['content']}"
            for m in state["messages"]
        )

    return f"""
        {CONSULTANT_PROMPT}
        
        ==================================================
        CONVERSATION HISTORY
        
        {history}
        
        ==================================================
        KNOWN CLOTHING DETAILS
        
        {known_text}
        
        ==================================================
        MISSING DETAILS
        
        {missing_text}
        
        ==================================================
        LATEST USER MESSAGE
        
        {state["user_message"]}
        
        ==================================================
        
        The conversation history is provided above.
        
        The Known Clothing Details are the current confirmed clothing design.
        
        The Missing Details are the only clothing attributes that still need to be collected.
        
        Always answer the user's latest message first.
        
        If the latest message asks a question, answer it naturally.
        
        If the latest message provides new clothing information, use the Known Details and Missing Details to continue the consultation naturally.
        
        Do not repeat questions for attributes that are already known.
        
        Respond ONLY with the assistant's reply.
    """


####################################################
# Extractor Prompt
####################################################

def build_extractor_prompt(state: FashionState):

    return f"""
        {EXTRACTOR_PROMPT}
        
        ==================================================
        CURRENT STATE
        
        Category: {state["category"]}
        Color: {state["color"]}
        Material: {state["material"]}
        Fit: {state["fit"]}
        Neckline: {state["neckline"]}
        Sleeve Length: {state["sleeve_length"]}
        Pattern: {state["pattern"]}
        
        ==================================================
        LATEST USER MESSAGE
        
        {state["user_message"]}
    """