from langgraph.graph import StateGraph, END

from state import FashionState

from nodes import (
    extractor_node,
    consultant_node,
    caption_builder_node,
    sdxl_node,
)


####################################################
# Routing
####################################################

def route_after_consultant(state: FashionState):

    if state["finished"]:
        return "caption_builder"

    return END


####################################################
# Build Graph
####################################################

builder = StateGraph(FashionState)

####################################################
# Nodes
####################################################

builder.add_node(
    "extractor",
    extractor_node,
)

builder.add_node(
    "consultant",
    consultant_node,
)

builder.add_node(
    "caption_builder",
    caption_builder_node,
)

builder.add_node(
    "sdxl",
    sdxl_node,
)

####################################################
# Entry Point
####################################################

builder.set_entry_point(
    "extractor"
)

####################################################
# Edges
####################################################

builder.add_edge(
    "extractor",
    "consultant",
)

builder.add_conditional_edges(
    "consultant",
    route_after_consultant,
)

builder.add_edge(
    "caption_builder",
    "sdxl",
)

builder.add_edge(
    "sdxl",
    END,
)

####################################################
# Compile
####################################################

graph = builder.compile()