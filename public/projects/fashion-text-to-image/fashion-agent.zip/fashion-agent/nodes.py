import json
from state import FashionState
from models import chat
from validators import validate_finished
from image_generator import ClothingGenerator
from prompt_builder import build_consultant_prompt, build_extractor_prompt

ALLOWED_FIELDS = {
    "category",
    "color",
    "material",
    "fit",
    "neckline",
    "sleeve_length",
    "pattern",
}

generator = None

####################################################
# Fashion Consultant Agent
####################################################

def consultant_node(state: FashionState):

    ####################################################
    # Build Prompt
    ####################################################

    system_prompt = build_consultant_prompt(state)

    ####################################################
    # Generate Response
    ####################################################

    assistant_response = chat(
        system_prompt,
        state["user_message"],
    )

    ####################################################
    # Save Response
    ####################################################

    state["next_response"] = assistant_response

    state["messages"].append(
        {
            "role": "assistant",
            "content": assistant_response,
        }
    )

    return state


####################################################
# Attribute Extractor Agent
####################################################

def extractor_node(state: FashionState):

    state["messages"].append(
        {
            "role": "user",
            "content": state["user_message"],
        }
    )

    ####################################################
    # Build Prompt
    ####################################################

    system_prompt = build_extractor_prompt(state)

    ####################################################
    # Generate
    ####################################################

    response = chat(
        system_prompt,
        state["user_message"],
    )

    print("\n===== Extractor =====")
    print(response)

    ####################################################
    # Parse JSON
    ####################################################

    try:

        start = response.find("{")
        end = response.rfind("}") + 1

        response = response[start:end]

        result = json.loads(response)

    except Exception:

        print("Extractor returned invalid JSON.")

        return state

    ####################################################
    # Update State
    ####################################################

    updates = result.get("state_update", {})

    for key, value in updates.items():

        if key in ALLOWED_FIELDS:

            state[key] = value

    ####################################################
    # Finished?
    ####################################################

    state["finished"] = validate_finished(state)

    return state


####################################################
# Caption Builder Agent
####################################################

def caption_builder_node(state: FashionState):

    print("\n===== Caption Formatter =====")

    attributes = [
        state["category"],
        state["color"],
        state["material"],
        state["sleeve_length"],
        state["neckline"],
        state["fit"],
        state["pattern"],
    ]

    caption = ", ".join(
        attribute.strip()
        for attribute in attributes
        if attribute
    )

    state["generated_caption"] = caption

    print(caption)

    return state


####################################################
# SDXL Generation Agent
####################################################

def sdxl_node(state: FashionState):

    print("\n===== SDXL Generation =====")

    global generator
    if generator is None:
        generator = ClothingGenerator(
            model_path="stabilityai/stable-diffusion-xl-base-1.0",
            checkpoint_path="/teamspace/studios/this_studio/src/unet_only.pth",
        )

    image = generator.generate_image(

        prompt=state["generated_caption"],
    )

    state["generated_image"] = image

    return state