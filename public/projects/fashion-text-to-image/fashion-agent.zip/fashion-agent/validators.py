import re

REQUIRED_ATTRIBUTES = [
    "category",
    "color",
    "material",
    "fit",
    "neckline",
    "sleeve_length",
    "pattern",
]

FORBIDDEN_TOPICS = [
    "size",
    "price",
    "brand",
    "occasion",
]


def get_missing_attributes(state):

    missing = []

    for attr in REQUIRED_ATTRIBUTES:

        if state[attr] is None:
            missing.append(attr)

    return missing


def validate_finished(state):

    return len(get_missing_attributes(state)) == 0


def validate_response(response: str):

    response = response.lower()

    for topic in FORBIDDEN_TOPICS:

        # Match complete words only
        if re.search(rf"\b{re.escape(topic)}\b", response):
            return False

    return True