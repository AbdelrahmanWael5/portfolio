from typing import Optional, List
from typing_extensions import TypedDict
from PIL.Image import Image

class FashionState(TypedDict):

    ####################################################
    # Conversation
    ####################################################

    messages: List[dict]

    user_message: str

    next_response: str

    ####################################################
    # Clothing State
    ####################################################

    category: Optional[str]
    color: Optional[str]
    material: Optional[str]
    fit: Optional[str]
    neckline: Optional[str]
    sleeve_length: Optional[str]
    pattern: Optional[str]

    ####################################################
    # Final Caption
    ####################################################

    generated_caption: Optional[str]
    generated_image: Optional[Image]

    ####################################################
    # Finished
    ####################################################

    finished: bool