import streamlit as st

from graph import graph

st.set_page_config(
    page_title="Fashion AI Consultant",
    page_icon="👔",
    layout="wide",
)

####################################################
# Initialize Session State
####################################################

if "state" not in st.session_state:

    st.session_state.state = {

        "user_message": "",

        "messages": [],

        "next_response": "",

        "category": None,
        "color": None,
        "material": None,
        "fit": None,
        "neckline": None,
        "sleeve_length": None,
        "pattern": None,

        "generated_caption": None,
        "generated_image": None,

        "finished": False,
    }

####################################################
# Page Title
####################################################

st.title("👔 Fashion AI Consultant")

####################################################
# Layout
####################################################

left, right = st.columns([2, 1])

####################################################
# LEFT COLUMN
####################################################

with left:

    st.subheader("Conversation")

    for message in st.session_state.state["messages"]:

        with st.chat_message(message["role"]):
            st.write(message["content"])

####################################################
# RIGHT COLUMN
####################################################

with right:

    st.subheader("Current Design")

    state = st.session_state.state

    st.markdown(f"**Category:** {state['category']}")
    st.markdown(f"**Color:** {state['color']}")
    st.markdown(f"**Material:** {state['material']}")
    st.markdown(f"**Fit:** {state['fit']}")
    st.markdown(f"**Neckline:** {state['neckline']}")
    st.markdown(f"**Sleeve Length:** {state['sleeve_length']}")
    st.markdown(f"**Pattern:** {state['pattern']}")

    if state["generated_image"] is not None:

        st.divider()

        st.subheader("Generated Image")

        st.image(
            state["generated_image"],
            use_container_width=True,
        )

####################################################
# Chat Input
####################################################

prompt = st.chat_input("Describe your clothing...")

if prompt:

    ####################################################
    # Show User Message
    ####################################################

    with left:

        with st.chat_message("user"):

            st.write(prompt)

    ####################################################
    # Invoke LangGraph
    ####################################################

    st.session_state.state["user_message"] = prompt

    st.session_state.state = graph.invoke(
        st.session_state.state
    )

    ####################################################
    # Refresh UI
    ####################################################

    st.rerun()